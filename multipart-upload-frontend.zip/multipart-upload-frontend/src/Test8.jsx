import React, { useState } from "react";

function Test8() {
    const [file, setFile] = useState(null);

    const handleFileChange = (e) => {
        setFile(e.target.files[0]);
    };

    const handleUpload = async () => {
        if (!file) return;

        const response = await fetch("http://127.0.0.1:5000/upload_7", {
            method: "POST",
            headers: {
                "X-File-Name": encodeURIComponent(file.name),
                "Content-Type": "application/octet-stream",
            },
            body: file, // Browser streams this automatically
        });

        const result = await response.json();
        console.log(result);
    };

    return (
        <div>
            <input type="file" onChange={handleFileChange} />
            <button onClick={handleUpload}>Upload</button>
        </div>
    );
}

export default Test8;
