import React, { useState, useRef } from 'react';

const Test9 = () => {
    const [selectedFile, setSelectedFile] = useState(null);
    const [uploading, setUploading] = useState(false);
    const [uploadProgress, setUploadProgress] = useState(0);
    const [uploadResult, setUploadResult] = useState(null);
    const [error, setError] = useState(null);
    const fileInputRef = useRef(null);

    // Convert file to base64
    const fileToBase64 = (file) => {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => {
                // Remove the data:mime;base64, prefix
                const base64 = reader.result.split(',')[1];
                resolve(base64);
            };
            reader.onerror = (error) => reject(error);
        });
    };

    // Handle file selection
    const handleFileSelect = (event) => {
        const file = event.target.files[0];
        setError(null);
        setUploadResult(null);

        if (!file) {
            setSelectedFile(null);
            return;
        }

        // Check file size (100MB limit)
        const maxSize = 100 * 1024 * 1024; // 100MB
        if (file.size > maxSize) {
            setError('File size exceeds 100MB limit');
            setSelectedFile(null);
            return;
        }

        setSelectedFile(file);
    };

    // Upload file
    const uploadFile = async () => {
        if (!selectedFile) {
            setError('Please select a file');
            return;
        }

        setUploading(true);
        setUploadProgress(0);
        setError(null);
        setUploadResult(null);

        try {
            // Convert file to base64
            setUploadProgress(10);
            const base64Content = await fileToBase64(selectedFile);
            setUploadProgress(30);

            // Prepare payload
            const payload = {
                filename: selectedFile.name,
                file_content: base64Content,
                file_type: selectedFile.type,
                file_size: selectedFile.size
            };

            setUploadProgress(50);

            // Upload using fetch
            const response = await fetch('http://127.0.0.1:5000/upload_9', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(payload)
            });

            setUploadProgress(90);

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
            }

            const result = await response.json();
            setUploadProgress(100);
            setUploadResult(result);

            // Reset form
            setSelectedFile(null);
            if (fileInputRef.current) {
                fileInputRef.current.value = '';
            }

        } catch (err) {
            setError(err.message);
            setUploadProgress(0);
        } finally {
            setUploading(false);
        }
    };

    // Format file size for display
    const formatFileSize = (bytes) => {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    };

    return (
        <div style={{ padding: '20px', maxWidth: '600px', margin: '0 auto' }}>
            <h2>Large File Upload (Up to 100MB)</h2>

            {/* File Input */}
            <div style={{ marginBottom: '20px' }}>
                <input
                    ref={fileInputRef}
                    type="file"
                    onChange={handleFileSelect}
                    style={{ marginBottom: '10px', width: '100%' }}
                    disabled={uploading}
                />

                {selectedFile && (
                    <div style={{
                        padding: '10px',
                        backgroundColor: '#f0f0f0',
                        borderRadius: '4px',
                        marginTop: '10px'
                    }}>
                        <strong>Selected File:</strong><br />
                        Name: {selectedFile.name}<br />
                        Size: {formatFileSize(selectedFile.size)}<br />
                        Type: {selectedFile.type || 'Unknown'}
                    </div>
                )}
            </div>

            {/* Upload Button */}
            <button
                onClick={uploadFile}
                // disabled={!selectedFile || uploading}
                style={{
                    padding: '12px 24px',
                    backgroundColor: uploading ? '#ccc' : '#007bff',
                    color: 'white',
                    border: 'none',
                    borderRadius: '4px',
                    cursor: uploading ? 'not-allowed' : 'pointer',
                    fontSize: '16px',
                    marginBottom: '20px'
                }}
            >
                {uploading ? 'Uploading...' : 'Upload File'}
            </button>

            {/* Progress Bar */}
            {uploading && (
                <div style={{ marginBottom: '20px' }}>
                    <div style={{ marginBottom: '5px' }}>
                        Upload Progress: {uploadProgress}%
                    </div>
                    <div style={{
                        width: '100%',
                        backgroundColor: '#e0e0e0',
                        borderRadius: '4px',
                        overflow: 'hidden'
                    }}>
                        <div
                            style={{
                                width: `${uploadProgress}%`,
                                height: '20px',
                                backgroundColor: '#007bff',
                                transition: 'width 0.3s ease'
                            }}
                        />
                    </div>
                </div>
            )}

            {/* Error Message
            {error && (
                <div style={{
                    padding: '10px',
                    backgroundColor: '#ffebee',
                    color: '#c62828',
                    border: '1px solid #ffcdd2',
                    borderRadius: '4px',
                    marginBottom: '20px'
                }}>
                    <strong>Error:</strong> {error}
                </div>
            )} */}

            {/* Success Message */}
            {uploadResult && (
                <div style={{
                    padding: '10px',
                    backgroundColor: '#e8f5e8',
                    color: '#2e7d32',
                    border: '1px solid #c8e6c9',
                    borderRadius: '4px',
                    marginBottom: '20px'
                }}>
                    <strong>Upload Successful!</strong><br />
                    Filename: {uploadResult.filename}<br />
                    Size: {formatFileSize(uploadResult.size)}<br />
                    Type: {uploadResult.type}<br />
                    Message: {uploadResult.message}
                </div>
            )}
        </div>
    );
};

export default Test9;