


import React, { useState } from 'react';
import axios from "axios";

const CHUNK_SIZE = 1024 * 1024 * 10; // 1MB
const MULTIPART_THRESHOLD = 5 * 1024 * 1024; // 5MB
const API_URL = 'http://127.0.0.1:5000'; // Flask server URL

const FileUploader = () => {
    const [progress, setProgress] = useState(0);
    const [uploading, setUploading] = useState(false);
    const [message, setMessage] = useState('');


    const handleUpload = async (file) => {
        const CHUNK_SIZE = 5 * 1024 * 1024;
        const totalChunks = Math.ceil(file.size / CHUNK_SIZE);

        const uploadChunk = async (chunk, start) => {
            const formData = new FormData();
            formData.append("chunk", chunk);
            formData.append("fileName", file.name);
            formData.append("start", start);
            formData.append("fileSize", file.size);

            await axios.post("http://127.0.0.1:5000/upload_4", formData);
        };

        let promises = [];
        for (let i = 0; i < totalChunks; i++) {
            const start = i * CHUNK_SIZE;
            const chunk = file.slice(start, start + CHUNK_SIZE);
            promises.push(uploadChunk(chunk, start));
        }

        await Promise.all(promises);
    };

    // Test server connection
    const testServer = async () => {
        try {
            const response = await fetch(`${API_URL}/api/test`);
            const data = await response.json();
            setMessage(`✅ Server test: ${data.message}`);
        } catch (error) {
            setMessage(`❌ Server test failed: ${error.message}`);
        }
    };

    return (
        <div style={{ padding: '20px', fontFamily: 'Arial' }}>
            <h3>File Upload</h3>

            <button onClick={testServer} style={{ marginBottom: '10px' }}>
                Test Server
            </button>

            <br />

            <input
                type="file"
                onChange={(e) => e.target.files[0] && handleUpload(e.target.files[0])}
                disabled={uploading}
            />

            {uploading && (
                <div style={{ marginTop: '10px' }}>
                    <div style={{
                        width: '300px',
                        height: '20px',
                        backgroundColor: '#ddd',
                        borderRadius: '10px',
                        overflow: 'hidden'
                    }}>
                        <div style={{
                            width: `${progress}%`,
                            height: '100%',
                            backgroundColor: '#4caf50',
                            transition: 'width 0.3s'
                        }} />
                    </div>
                    <p>{Math.round(progress)}% - {uploading ? 'Uploading...' : 'Complete'}</p>
                </div>
            )}

            {message && (
                <div style={{
                    marginTop: '10px',
                    padding: '10px',
                    backgroundColor: message.includes('❌') ? '#ffebee' : '#e8f5e8',
                    borderRadius: '4px'
                }}>
                    {message}
                </div>
            )}
        </div>
    );
};

export default FileUploader;