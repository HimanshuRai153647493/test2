// /**
//  * Complete React Frontend for Multipart File Upload
//  * Supports both single upload and multipart upload with progress tracking
//  */

// import React, { useState, useCallback, useRef } from 'react';

// // Configuration
// const CONFIG = {
//     CHUNK_SIZE: 1024 * 1024, // 1MB chunks
//     MULTIPART_THRESHOLD: 5 * 1024 * 1024, // 5MB threshold
//     MAX_FILE_SIZE: 100 * 1024 * 1024, // 100MB max
//     MAX_RETRIES: 3,
//     RETRY_DELAY: 1000, // 1 second
//     API_BASE_URL: 'http://127.0.0.1:5000', // Empty for same origin, or 'http://127.0.0.1:5000' for different port
// };

// const FileUploader = () => {
//     // State management
//     const [uploadProgress, setUploadProgress] = useState(0);
//     const [isUploading, setIsUploading] = useState(false);
//     const [uploadStatus, setUploadStatus] = useState('');
//     const [uploadSpeed, setUploadSpeed] = useState(0);
//     const [eta, setEta] = useState(0);
//     const [uploadedFiles, setUploadedFiles] = useState([]);
//     const [errorMessage, setErrorMessage] = useState('');
//     const [isDragOver, setIsDragOver] = useState(false);

//     // Refs for upload control
//     const abortControllerRef = useRef(null);
//     const startTimeRef = useRef(null);
//     const uploadedBytesRef = useRef(0);

//     // Utility functions
//     const formatFileSize = (bytes) => {
//         if (bytes === 0) return '0 Bytes';
//         const k = 1024;
//         const sizes = ['Bytes', 'KB', 'MB', 'GB'];
//         const i = Math.floor(Math.log(bytes) / Math.log(k));
//         return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
//     };

//     const formatSpeed = (bytesPerSecond) => {
//         return formatFileSize(bytesPerSecond) + '/s';
//     };

//     const formatTime = (seconds) => {
//         if (seconds < 60) return `${Math.round(seconds)}s`;
//         const minutes = Math.floor(seconds / 60);
//         const remainingSeconds = Math.round(seconds % 60);
//         return `${minutes}m ${remainingSeconds}s`;
//     };

//     const generateUploadId = () => {
//         return `upload_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
//     };

//     // API request helper with error handling
//     const makeRequest = async (endpoint, data, retries = CONFIG.MAX_RETRIES) => {
//         const url = `${CONFIG.API_BASE_URL}/api${endpoint}`;

//         for (let attempt = 0; attempt <= retries; attempt++) {
//             try {
//                 if (abortControllerRef.current?.signal.aborted) {
//                     throw new Error('Upload cancelled');
//                 }

//                 const response = await fetch(url, {
//                     method: 'POST',
//                     headers: { 'Content-Type': 'application/json' },
//                     body: JSON.stringify(data),
//                     signal: abortControllerRef.current?.signal
//                 });

//                 // Check if response is JSON
//                 const contentType = response.headers.get('content-type');
//                 if (!contentType || !contentType.includes('application/json')) {
//                     const textResponse = await response.text();
//                     throw new Error(`Server error: Expected JSON, got HTML. Response: ${textResponse.substring(0, 200)}...`);
//                 }

//                 if (!response.ok) {
//                     const errorData = await response.json();
//                     throw new Error(errorData.error || `HTTP ${response.status}`);
//                 }

//                 return await response.json();
//             } catch (error) {
//                 if (error.name === 'AbortError' || error.message.includes('cancelled')) {
//                     throw error;
//                 }

//                 if (attempt < retries) {
//                     console.warn(`Request attempt ${attempt + 1} failed, retrying...`, error);
//                     await new Promise(resolve => setTimeout(resolve, CONFIG.RETRY_DELAY * Math.pow(2, attempt)));
//                 } else {
//                     throw error;
//                 }
//             }
//         }
//     };

//     // Convert file to base64
//     const fileToBase64 = (file) => {
//         return new Promise((resolve, reject) => {
//             const reader = new FileReader();
//             reader.onload = () => resolve(reader.result.split(',')[1]);
//             reader.onerror = reject;
//             reader.readAsDataURL(file);
//         });
//     };

//     // Single file upload (existing method)
//     const uploadSingleFile = async (file) => {
//         setUploadStatus('Preparing single upload...');

//         try {
//             const base64Data = await fileToBase64(file);

//             setUploadStatus('Uploading file...');
//             const result = await makeRequest('/upload', {
//                 filename: file.name,
//                 data: base64Data,
//                 size: file.size,
//                 type: file.type
//             });

//             return result;
//         } catch (error) {
//             throw new Error(`Single upload failed: ${error.message}`);
//         }
//     };

//     // Multipart file upload
//     const uploadMultipartFile = async (file) => {
//         const totalChunks = Math.ceil(file.size / CONFIG.CHUNK_SIZE);
//         const uploadId = generateUploadId();

//         setUploadStatus(`Initializing multipart upload (${totalChunks} chunks)...`);

//         try {
//             // 1. Initialize upload
//             await makeRequest('/upload/init', {
//                 uploadId,
//                 filename: file.name,
//                 totalChunks,
//                 fileSize: file.size,
//                 fileType: file.type
//             });

//             setUploadStatus('Uploading chunks...');
//             startTimeRef.current = Date.now();
//             uploadedBytesRef.current = 0;

//             // 2. Upload chunks
//             for (let chunkIndex = 0; chunkIndex < totalChunks; chunkIndex++) {
//                 if (abortControllerRef.current?.signal.aborted) {
//                     throw new Error('Upload cancelled');
//                 }

//                 const start = chunkIndex * CONFIG.CHUNK_SIZE;
//                 const end = Math.min(start + CONFIG.CHUNK_SIZE, file.size);
//                 const chunk = file.slice(start, end);

//                 // Convert chunk to base64
//                 const base64Chunk = await fileToBase64(chunk);

//                 // Upload chunk
//                 await makeRequest('/upload/chunk', {
//                     uploadId,
//                     chunkIndex,
//                     data: base64Chunk
//                 });

//                 // Update progress and speed
//                 uploadedBytesRef.current += chunk.size;
//                 const progress = (uploadedBytesRef.current / file.size) * 100;
//                 setUploadProgress(progress);

//                 // Calculate speed and ETA
//                 const elapsed = (Date.now() - startTimeRef.current) / 1000;
//                 const speed = uploadedBytesRef.current / elapsed;
//                 const remainingBytes = file.size - uploadedBytesRef.current;
//                 const estimatedTimeRemaining = remainingBytes / speed;

//                 setUploadSpeed(speed);
//                 setEta(estimatedTimeRemaining);
//                 setUploadStatus(`Uploading chunk ${chunkIndex + 1}/${totalChunks}...`);
//             }

//             // 3. Complete upload
//             setUploadStatus('Finalizing upload...');
//             const result = await makeRequest('/upload/complete', {
//                 uploadId,
//                 filename: file.name
//             });

//             return result;
//         } catch (error) {
//             // Cleanup on error
//             try {
//                 await makeRequest('/upload/abort', { uploadId });
//             } catch (abortError) {
//                 console.warn('Failed to abort upload:', abortError);
//             }
//             throw error;
//         }
//     };

//     // Main upload handler
//     const handleFileUpload = useCallback(async (file) => {
//         // Reset state
//         setIsUploading(true);
//         setUploadProgress(0);
//         setUploadStatus('');
//         setUploadSpeed(0);
//         setEta(0);
//         setErrorMessage('');
//         uploadedBytesRef.current = 0;

//         // Create abort controller
//         abortControllerRef.current = new AbortController();

//         try {
//             // Validate file
//             if (!file) {
//                 throw new Error('No file selected');
//             }

//             if (file.size > CONFIG.MAX_FILE_SIZE) {
//                 throw new Error(`File size (${formatFileSize(file.size)}) exceeds maximum allowed size (${formatFileSize(CONFIG.MAX_FILE_SIZE)})`);
//             }

//             let result;

//             // Choose upload method based on file size
//             if (file.size <= CONFIG.MULTIPART_THRESHOLD) {
//                 console.log('Using single upload for small file');
//                 result = await uploadSingleFile(file);
//                 setUploadProgress(100);
//             } else {
//                 console.log('Using multipart upload for large file');
//                 result = await uploadMultipartFile(file);
//             }

//             // Success
//             setUploadStatus(`Upload completed: ${file.name}`);
//             setUploadedFiles(prev => [...prev, {
//                 ...result,
//                 uploadTime: new Date().toLocaleString(),
//                 originalSize: file.size
//             }]);

//             console.log('Upload successful:', result);

//             // Reset after delay
//             setTimeout(() => {
//                 setUploadStatus('');
//                 setUploadProgress(0);
//                 setUploadSpeed(0);
//                 setEta(0);
//             }, 3000);

//         } catch (error) {
//             if (error.name === 'AbortError' || error.message.includes('cancelled')) {
//                 setUploadStatus('Upload cancelled');
//                 setErrorMessage('Upload was cancelled by user');
//             } else {
//                 setUploadStatus(`Upload failed: ${error.message}`);
//                 setErrorMessage(error.message);
//             }
//             console.error('Upload error:', error);
//         } finally {
//             setIsUploading(false);
//             abortControllerRef.current = null;
//         }
//     }, []);

//     // Cancel upload
//     const cancelUpload = () => {
//         if (abortControllerRef.current) {
//             abortControllerRef.current.abort();
//         }
//     };

//     // File input handler
//     const handleFileSelect = (event) => {
//         const file = event.target.files[0];
//         if (file) {
//             handleFileUpload(file);
//         }
//     };

//     // Drag and drop handlers
//     const handleDragOver = (event) => {
//         event.preventDefault();
//         setIsDragOver(true);
//     };

//     const handleDragLeave = (event) => {
//         event.preventDefault();
//         setIsDragOver(false);
//     };

//     const handleDrop = (event) => {
//         event.preventDefault();
//         setIsDragOver(false);
//         const files = event.dataTransfer.files;
//         if (files.length > 0) {
//             handleFileUpload(files[0]);
//         }
//     };

//     return (
//         <div style={{ maxWidth: '600px', margin: '0 auto', padding: '20px', fontFamily: 'Arial, sans-serif' }}>
//             {/* <h2 style={{ textAlign: 'center', color: '#333', marginBottom: '30px' }}>
//                 File Upload System
//             </h2> */}

//             {/* Upload Method Info */}
//             {isUploading && (
//                 <div style={{
//                     backgroundColor: '#e3f2fd',
//                     padding: '10px',
//                     borderRadius: '4px',
//                     marginBottom: '20px',
//                     fontSize: '14px',
//                     color: '#1565c0'
//                 }}>
//                     {uploadedBytesRef.current === 0
//                         ? 'Determining upload method...'
//                         : `Using ${uploadProgress < 100 ? 'multipart' : 'single'} upload`
//                     }
//                 </div>
//             )}

//             {/* Upload Area */}
//             <div
//                 onDragOver={handleDragOver}
//                 onDragLeave={handleDragLeave}
//                 onDrop={handleDrop}
//                 style={{
//                     border: `2px dashed ${isDragOver ? '#4CAF50' : '#ccc'}`,
//                     borderRadius: '8px',
//                     padding: '40px',
//                     textAlign: 'center',
//                     backgroundColor: isDragOver ? '#e8f5e8' : '#f9f9f9',
//                     marginBottom: '20px',
//                     cursor: isUploading ? 'not-allowed' : 'pointer',
//                     transition: 'all 0.3s ease'
//                 }}
//             >
//                 <input
//                     type="file"
//                     onChange={handleFileSelect}
//                     disabled={isUploading}
//                     style={{
//                         marginBottom: '10px',
//                         padding: '5px',
//                         width: '100%'
//                     }}
//                 />
//                 <p style={{ margin: '10px 0', color: '#666' }}>
//                     Or drag and drop a file here
//                 </p>
//                 <p style={{ margin: '0', fontSize: '12px', color: '#999' }}>
//                     Maximum file size: {formatFileSize(CONFIG.MAX_FILE_SIZE)}
//                 </p>
//                 <p style={{ margin: '5px 0 0 0', fontSize: '12px', color: '#666' }}>
//           Files ≤ 5MB use single upload • Files > 5MB use multipart upload
//                 </p>
//             </div>

//             {/* Upload Progress */}
//             {isUploading && (
//                 <div style={{ marginBottom: '20px' }}>
//                     <div style={{
//                         width: '100%',
//                         height: '20px',
//                         backgroundColor: '#e0e0e0',
//                         borderRadius: '10px',
//                         overflow: 'hidden',
//                         marginBottom: '10px'
//                     }}>
//                         <div style={{
//                             width: `${uploadProgress}%`,
//                             height: '100%',
//                             backgroundColor: '#4CAF50',
//                             transition: 'width 0.3s ease',
//                             borderRadius: '10px'
//                         }} />
//                     </div>

//                     <div style={{
//                         display: 'flex',
//                         justifyContent: 'space-between',
//                         fontSize: '14px',
//                         color: '#666',
//                         marginBottom: '10px'
//                     }}>
//                         <span>{Math.round(uploadProgress)}%</span>
//                         {uploadSpeed > 0 && (
//                             <span>{formatSpeed(uploadSpeed)}</span>
//                         )}
//                         {eta > 0 && (
//                             <span>ETA: {formatTime(eta)}</span>
//                         )}
//                     </div>

//                     <p style={{ margin: '10px 0', fontSize: '14px' }}>{uploadStatus}</p>

//                     <button
//                         onClick={cancelUpload}
//                         style={{
//                             padding: '8px 16px',
//                             backgroundColor: '#f44336',
//                             color: 'white',
//                             border: 'none',
//                             borderRadius: '4px',
//                             cursor: 'pointer',
//                             fontSize: '14px',
//                             transition: 'background-color 0.3s ease'
//                         }}
//                         onMouseOver={(e) => e.target.style.backgroundColor = '#d32f2f'}
//                         onMouseOut={(e) => e.target.style.backgroundColor = '#f44336'}
//                     >
//                         Cancel Upload
//                     </button>
//                 </div>
//             )}

//             {/* Error Message */}
//             {errorMessage && (
//                 <div style={{
//                     backgroundColor: '#ffebee',
//                     color: '#c62828',
//                     padding: '10px',
//                     borderRadius: '4px',
//                     marginBottom: '20px',
//                     border: '1px solid #ffcdd2'
//                 }}>
//                     <strong>Error:</strong> {errorMessage}
//                 </div>
//             )}

//             {/* Success Message */}
//             {uploadStatus && !isUploading && !errorMessage && (
//                 <div style={{
//                     backgroundColor: uploadStatus.includes('failed') ? '#ffebee' : '#e8f5e8',
//                     color: uploadStatus.includes('failed') ? '#c62828' : '#2e7d32',
//                     padding: '10px',
//                     borderRadius: '4px',
//                     marginBottom: '20px',
//                     border: `1px solid ${uploadStatus.includes('failed') ? '#ffcdd2' : '#c8e6c8'}`
//                 }}>
//                     {uploadStatus}
//                 </div>
//             )}

//             {/* Uploaded Files List */}
//             {uploadedFiles.length > 0 && (
//                 <div>
//                     <h3 style={{ marginBottom: '15px', color: '#333' }}>Uploaded Files</h3>
//                     <div style={{ maxHeight: '300px', overflowY: 'auto' }}>
//                         {uploadedFiles.map((file, index) => (
//                             <div key={index} style={{
//                                 backgroundColor: '#f5f5f5',
//                                 padding: '15px',
//                                 marginBottom: '10px',
//                                 borderRadius: '4px',
//                                 border: '1px solid #ddd'
//                             }}>
//                                 <div style={{ fontWeight: 'bold', marginBottom: '5px' }}>
//                                     {file.filename}
//                                 </div>
//                                 <div style={{ fontSize: '12px', color: '#666' }}>
//                                     Size: {formatFileSize(file.size)} |
//                                     Uploaded: {file.uploadTime}
//                                     {file.path && ` | Path: ${file.path}`}
//                                 </div>
//                             </div>
//                         ))}
//                     </div>
//                 </div>
//             )}
//         </div>
//     );
// };

// export default FileUploader;








import React, { useState } from 'react';

const CHUNK_SIZE = 1024 * 1024 * 10; // 1MB
const MULTIPART_THRESHOLD = 5 * 1024 * 1024; // 5MB
const API_URL = 'http://127.0.0.1:5000'; // Flask server URL

const FileUploader = () => {
    const [progress, setProgress] = useState(0);
    const [uploading, setUploading] = useState(false);
    const [message, setMessage] = useState('');

    const makeRequest = async (endpoint, data) => {
        const response = await fetch(`${API_URL}/api${endpoint}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });

        const text = await response.text();

        // Check if response is JSON
        try {
            return JSON.parse(text);
        } catch (e) {
            throw new Error(`Server returned HTML instead of JSON: ${text.substring(0, 100)}...`);
        }
    };

    const fileToBase64 = (file) => {
        return new Promise((resolve) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result.split(',')[1]);
            reader.readAsDataURL(file);
        });
    };

    const singleUpload = async (file) => {
        const base64Data = await fileToBase64(file);
        return await makeRequest('/upload', {
            filename: file.name,
            data: base64Data,
            size: file.size
        });
    };

    const multipartUpload = async (file) => {
        const totalChunks = Math.ceil(file.size / CHUNK_SIZE);
        const uploadId = `upload_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

        // Initialize
        await makeRequest('/upload/init', {
            uploadId,
            filename: file.name,
            totalChunks
        });

        // Upload chunks
        for (let i = 0; i < totalChunks; i++) {
            const start = i * CHUNK_SIZE;
            const end = Math.min(start + CHUNK_SIZE, file.size);
            const chunk = file.slice(start, end);

            const base64Chunk = await fileToBase64(chunk);

            await makeRequest('/upload/chunk', {
                uploadId,
                chunkIndex: i,
                data: base64Chunk
            });

            setProgress(((i + 1) / totalChunks) * 100);
        }

        // Complete
        return await makeRequest('/upload/complete', { uploadId });
    };

    const handleUpload = async (file) => {
        setUploading(true);
        setProgress(0);
        setMessage('');

        try {
            let result;

            if (file.size <= MULTIPART_THRESHOLD) {
                result = await singleUpload(file);
                setProgress(100);
            } else {
                result = await multipartUpload(file);
            }

            setMessage(`✅ ${result.message}`);
        } catch (error) {
            setMessage(`❌ ${error.message}`);
        } finally {
            setUploading(false);
        }
    };

    // Test server connection
    const testServer = async () => {
        try {
            const response = await fetch(`${API_URL}/api/test`);
            const data = await response.json();
            setMessage(`✅ Server test: ${data.message}`);
        } catch (error) {
            setMessage(`❌ Server test failed: ${error.message}`);
        }
    };

    return (
        <div style={{ padding: '20px', fontFamily: 'Arial' }}>
            <h3>File Upload</h3>

            <button onClick={testServer} style={{ marginBottom: '10px' }}>
                Test Server
            </button>

            <br />

            <input
                type="file"
                onChange={(e) => e.target.files[0] && handleUpload(e.target.files[0])}
                disabled={uploading}
            />

            {uploading && (
                <div style={{ marginTop: '10px' }}>
                    <div style={{
                        width: '300px',
                        height: '20px',
                        backgroundColor: '#ddd',
                        borderRadius: '10px',
                        overflow: 'hidden'
                    }}>
                        <div style={{
                            width: `${progress}%`,
                            height: '100%',
                            backgroundColor: '#4caf50',
                            transition: 'width 0.3s'
                        }} />
                    </div>
                    <p>{Math.round(progress)}% - {uploading ? 'Uploading...' : 'Complete'}</p>
                </div>
            )}

            {message && (
                <div style={{
                    marginTop: '10px',
                    padding: '10px',
                    backgroundColor: message.includes('❌') ? '#ffebee' : '#e8f5e8',
                    borderRadius: '4px'
                }}>
                    {message}
                </div>
            )}
        </div>
    );
};

export default FileUploader;