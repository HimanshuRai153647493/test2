import React, { useState } from "react";

function Test6() {
    const [progress, setProgress] = useState(0);

    function arrayBufferToBase64(buffer) {
        return new Promise((resolve) => {
            const blob = new Blob([buffer], { type: "application/octet-stream" });
            const reader = new FileReader();
            reader.onload = () => {
                // result is like "data:application/octet-stream;base64,AAAA..."
                const base64 = reader.result.split(",")[1];
                resolve(base64);
            };
            reader.readAsDataURL(blob);
        });
    }

    const handleFileChange = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const chunkSize = 5 * 1024 * 1024; // 5MB
        let uploaded = 0;

        for (let start = 0; start < file.size; start += chunkSize) {
            const end = Math.min(start + chunkSize, file.size);
            const blob = file.slice(start, end);
            const arrayBuffer = await blob.arrayBuffer();
            const base64Chunk = await arrayBufferToBase64(arrayBuffer);

            const isLast = end >= file.size;

            await fetch("http://127.0.0.1:5000/upload_6", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    filename: file.name,
                    chunk: base64Chunk,
                    is_last: isLast,
                }),
            });

            uploaded = end;
            setProgress(((uploaded / file.size) * 100).toFixed(2));
        }

        alert("Upload complete!");
    };

    return (
        <div>
            <h2>Upload File</h2>
            <input type="file" onChange={handleFileChange} />
            <p>Progress: {progress}%</p>
        </div>
    );
}

export default Test6;
